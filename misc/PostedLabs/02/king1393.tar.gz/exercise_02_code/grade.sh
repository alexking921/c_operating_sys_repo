gcc -o list list.c
./list 1
./list 2
./list 3
./list 7
./list 11


