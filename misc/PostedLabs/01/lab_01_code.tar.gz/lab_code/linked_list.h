typedef struct lnode {
	int data;
	struct lnode *next;
} NODE;

NODE *HEAD = NULL;
