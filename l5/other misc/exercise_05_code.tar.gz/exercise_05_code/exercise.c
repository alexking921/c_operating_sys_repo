#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>

int numOfEntries(char* path) {
    /*
	TODO: 
        Count the number of entries in path
    */
}

int main(int argc, char** argv){
    if (argc < 2) {
        printf("Pass the path as an argument to the program");
        exit(1);
    }
    char* path = argv[1];

    DIR* dir = opendir(path);
    if(dir==NULL){
        printf("The path passed is invalid");
        return -1;
    }
    struct dirent* entry;
    
    /*
	TODO:   
	Iterate through the elements in argv[1]
	1.Check DT_DIR and DT_REG
	2.What if the entry is "." and ".."
        
    */
    
    closedir(dir);
    return 0;
}
