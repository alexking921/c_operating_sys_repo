#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv) {
	
	// take 'n' from the input and convert to integer
	// You can use strtol()
	
	// for i in n
	//		create child process
	//			print pid 
	//			call execl to print 'hello there' using 'echo'

	// parent waits for all child processes to terminate

	// parent create child process
	//		call execv on 'ptime' executable

	// parent waits for child to complete
	return 0;
}