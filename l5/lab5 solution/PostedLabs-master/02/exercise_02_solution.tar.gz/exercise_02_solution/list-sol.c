#include<stdio.h>
#include<stdlib.h>

struct node{
  int x;
  struct node * next;
};



struct node* create_list(struct node* head){

    //create first node
    head = (struct node*)malloc(sizeof(struct node));
    head->x=2;
    head->next=NULL;

    //create second node
    struct node * temp =(struct node*)malloc(sizeof(struct node));
    temp->x=6;
    temp->next=NULL;
    head->next=temp;

    //create third node
    struct node * temp2 =(struct node*)malloc(sizeof(struct node));
    temp2->x=10;
    temp2->next=NULL;
    head->next->next=temp2;

    return head;

}

void print_list(struct node* head){

  struct node* cur=head;

  while(cur!=NULL){
    printf("%d ", cur->x);
    cur=cur->next;
  }
  printf("\n");


}

struct node* insert_list (struct node* head, int num){
  //TO DO
  // create a node, store num there, and insert the node in the list so that the list remains in sorted order
  struct node * newnode =(struct node*)malloc(sizeof(struct node));
  newnode->x=num;
  newnode->next=NULL;

  if(num < head->x){ //if smaller than the first element
    newnode->next = head ;
    head = newnode ;
    return head ;
  }
  //check for insertion point
  struct node * cur = head ;
  while(cur->next!=NULL){
    if(cur->x <= num && num <= cur->next->x){//found insertion point
      newnode->next = cur->next ;
      cur->next = newnode ;
      return head;
    }
    else{
      cur=cur->next;
    }

  }
  //insert at last
  cur->next = newnode;
  return head;
}

int main (int argc, char** argv){
  if (argc < 2) {

  		printf("Invalid number of args. Please enter 1 argument\n");
  		exit(1);
  	}
    int num = atoi(argv[1]);

    //build an initial list
    struct node * head;
    head = create_list(head);

    head = insert_list(head, num);

    print_list(head);

    return 0;


}
