#ifndef _APPLE_H
#define _APPLE_H

int apple(void);

#endif /* _APPLE_H */

