#include <stdio.h>

int apple(void) {
	printf("I'm an apple.\n");
	return 0;
}

