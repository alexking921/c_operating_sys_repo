#ifndef INC_091420_BREAKOUT_MAJOR_H
#define INC_091420_BREAKOUT_MAJOR_H

void getMajor(char * major);

#endif //INC_091420_BREAKOUT_MAJOR_H
