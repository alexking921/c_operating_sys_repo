# PostedLabs
This repository will hold the published lab code for students to use git to access the labs

The repository is organized into sub-directories for each lab which include:
Lab Notes
Lab files in the form of a tar
Lab solutions (after they have been released)